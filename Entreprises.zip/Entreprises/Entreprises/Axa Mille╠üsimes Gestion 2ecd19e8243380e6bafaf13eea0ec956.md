# Axa Millésimes Gestion

Notes: 9 exceptional vineyards: Pichon Baron, Pibran, Suduiraut, Arlot, Quinta do Noval, Passadouro, Disznókő, Outpost & Platt

[Untitled](Axa%20Mill%C3%A9simes%20Gestion/Untitled%202ecd19e8243380a4b04ddb8d8eed1ecf.csv)

[Untitled](Axa%20Mill%C3%A9simes%20Gestion/Untitled%202ecd19e8243380d7a00ed1a0c8c24cc6.csv)

[Untitled](Axa%20Mill%C3%A9simes%20Gestion/Untitled%202ecd19e8243380998cddfb1b0e3e1d15.csv)

[Untitled](Axa%20Mill%C3%A9simes%20Gestion/Untitled%202ecd19e8243380dbbedcd7bb665266fd.csv)