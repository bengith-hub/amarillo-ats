# LCA Construction Bois

Localisation Principale: Cholet
Notes: filiale de Bonnin Charbonneau
Priorité: 3 - Pertinent
Secteur: BTP
Site web: http://www.lca-construction.fr
Source: Linkedin
Statut: A cibler
CA: 20 -50 M€
Taille: 51-200
Téléphone: 0251416472

[Untitled](LCA%20Construction%20Bois/Untitled%20300d19e8243380d49892c4f2630ceda1.csv)

[Untitled](LCA%20Construction%20Bois/Untitled%20300d19e8243380ddaec4c4bcd210f56f.csv)

[Untitled](LCA%20Construction%20Bois/Untitled%20300d19e82433801d973fc3cb868efbbf.csv)

[Untitled](LCA%20Construction%20Bois/Untitled%20300d19e82433809692b2eed4e59dafbc.csv)