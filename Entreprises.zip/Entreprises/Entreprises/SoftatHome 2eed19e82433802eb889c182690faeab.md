# SoftatHome

[Untitled](SoftatHome/Untitled%202eed19e8243380a6969cc5bd5151ca45.csv)

[Untitled](SoftatHome/Untitled%202eed19e824338094a78ee005912f2641.csv)

[Untitled](SoftatHome/Untitled%202eed19e8243380f2a4aae94728ab95ca.csv)

[Untitled](SoftatHome/Untitled%202eed19e82433802b965ce81746198315.csv)