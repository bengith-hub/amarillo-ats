# Maison BECAM

ICP fit: Oui
Localisation Principale: Saint Barthélémy d'Anjou
Notes: En termes de niveau, on est sur un DSI groupe ou Directeur des Systèmes d’Information et du Digital avec :
• périmètre groupe (siège + ateliers + réseau de boulangeries, y compris franchisés pour la partie outillage),
• rattachement direct à la Direction générale,
• rôle de conduite de la croissance (scaling du SI), plus que de simple maintien opérationnel.
En résumé : au vu des chiffres et de l’organisation, la fonction DSI est non seulement pertinente mais devient un levier stratégique pour accompagner le passage de 30 à 100 boulangeries
Priorité: 5 - Coeur de cible
Secteur: Retail
Site web: http://maisonbecam.com
Source: Linkedin
Statut: A cibler
CA: 20 -50 M€
Taille: 201-1000
Téléphone: 0241182096

[Untitled](Maison%20BECAM/Untitled%20301d19e82433801bbd9aebd6e24de2bc.csv)

[Untitled](Maison%20BECAM/Untitled%20301d19e82433803da6c2cd21eb669452.csv)

[Untitled](Maison%20BECAM/Untitled%20301d19e8243380559c32ee074746457f.csv)

[Untitled](Maison%20BECAM/Untitled%20301d19e82433802295bbcca7e21ad2bd.csv)