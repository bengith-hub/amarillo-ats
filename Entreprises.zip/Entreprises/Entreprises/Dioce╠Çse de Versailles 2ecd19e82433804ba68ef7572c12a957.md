# Diocèse de Versailles

Localisation Principale: Paris

[Untitled](Dioc%C3%A8se%20de%20Versailles/Untitled%202ecd19e82433808fa3d4e6ba699a123b.csv)

[Untitled](Dioc%C3%A8se%20de%20Versailles/Untitled%202ecd19e824338024bde0f67e486a0941.csv)

[Untitled](Dioc%C3%A8se%20de%20Versailles/Untitled%202ecd19e8243380b38888f341a68ce00b.csv)

[Untitled](Dioc%C3%A8se%20de%20Versailles/Untitled%202ecd19e82433807bbb3afeef5db980d2.csv)