# Groupe Pautric

Localisation Principale: Nantes
Notes: distribution automobile
Secteur: Retail
Site web: https://groupepautric.com/
CA: 250 M€+
Taille: 1000+

[Untitled](Groupe%20Pautric/Untitled%202f3d19e824338022aef9ed6a0d113ebb.csv)

[Untitled](Groupe%20Pautric/Untitled%202f3d19e82433805aaaeec3d485dd107c.csv)

[Untitled](Groupe%20Pautric/Untitled%202f3d19e8243380149e82f93c9573599e.csv)

[Untitled](Groupe%20Pautric/Untitled%202f3d19e824338031a5dcd60545fb7fc6.csv)