# Finance Conseil

Localisation Principale: Beaucouzé
Notes: pas de DSI seul un Dir webmarketing et digital Quentin BODET
Priorité: 5 - Coeur de cible
Secteur: Finance
Site web: https://www.financeconseil.fr
Source: Linkedin
Statut: A cibler
CA: 50 - 100 M€
Taille: 201-1000

[Untitled](Finance%20Conseil/Untitled%20301d19e82433804bb165dbaf37983a87.csv)

[Untitled](Finance%20Conseil/Untitled%20301d19e82433809e8c3ac268e3ec2b51.csv)

[Untitled](Finance%20Conseil/Untitled%20301d19e82433807d8b71f875990e6c53.csv)

[Untitled](Finance%20Conseil/Untitled%20301d19e8243380328c52d8fe0be62a77.csv)