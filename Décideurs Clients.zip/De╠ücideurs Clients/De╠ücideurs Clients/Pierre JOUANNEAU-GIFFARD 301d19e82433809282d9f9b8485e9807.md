# Pierre JOUANNEAU-GIFFARD

Entreprise: Giffard (../../Entreprises/Entreprises/Giffard%20301d19e8243380a18bc8dac42e581840.md)
Fonction: DG
Niveau de relation: Inconnu
Linkedin: https://www.linkedin.com/in/pierre-jouanneau-giffard-a2760b67
A relancer?: No
Niveau hiérarchique: COMEX
Rôle dans la décision: Co-décideur
Fonction macro: Direction générale
Priorité prospection: 🔴 Haute
Périmètre: Europe