# Jean-Michel THION

Entreprise: RIVARD (../../Entreprises/Entreprises/RIVARD%20301d19e824338074ad41fb9c1e5d7d0a.md)
Fonction: DG
Email: jean-michel.thion@rivard.fr
Téléphone: +33.6.66.81.66.29
Linkedin: https://www.linkedin.com/in/jean-michel-thion-business
A relancer?: No
Notes relation: 33625428981
Niveau hiérarchique: COMEX
Rôle dans la décision: Décideur
Fonction macro: Direction générale
Priorité prospection: 🔴 Haute
Périmètre: Europe
Localisation: Daumeray