# André LEFEVRE

Entreprise: CRUARD CHARPENTE ET CONSTRUCTIONS BOIS (../../Entreprises/Entreprises/CRUARD%20CHARPENTE%20ET%20CONSTRUCTIONS%20BOIS%20300d19e82433803b8379db85ab4d0db6.md)
Fonction: DG
Niveau de relation: Inconnu
Linkedin: linkedin.com/in/andré-lefevre-654517ab
A relancer?: No
Niveau hiérarchique: COMEX
Rôle dans la décision: Décideur
Fonction macro: Direction générale
Périmètre: France
Localisation: Laval