# Serge COMPAGNE

Entreprise: Voltéo (../../Entreprises/Entreprises/Volt%C3%A9o%202ecd19e8243380a4b7e5ee81b03fdfee.md)
Profil candidat: Serge COMPAGNE (../../Candidats/Candidats/Serge%20COMPAGNE%202ecd19e8243380379de5d8d5d2ede6be.md)
A relancer?: No
Localisation: Bordeaux