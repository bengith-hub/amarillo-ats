# Jerome MADOC

Entreprise: GOZOKI (../../Entreprises/Entreprises/GOZOKI%202f7d19e82433804a8b00c11d3a6108f4.md)
Fonction: DG Groupe
Niveau de relation: Echange en cours
Email: jerome_madoc@hotmail.com
Linkedin: https://www.linkedin.com/in/j%C3%A9r%C3%B4me-madoc-49a15b10/
A relancer?: No
Dernier contact: January 29, 2026
Niveau hiérarchique: COMEX
Rôle dans la décision: Décideur
Fonction macro: Direction générale
Priorité prospection: 🟠 Moyenne
Périmètre: France
Localisation: Estillac