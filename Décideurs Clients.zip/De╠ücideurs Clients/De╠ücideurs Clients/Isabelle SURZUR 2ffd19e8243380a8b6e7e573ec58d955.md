# Isabelle SURZUR

Entreprise: Etablissements Sogal (CMAI) (../../Entreprises/Entreprises/Etablissements%20Sogal%20(CMAI)%202ffd19e8243380a68c51cbef157854a8.md)
Fonction: DRH
Niveau de relation: Inconnu
Linkedin: linkedin.com/in/isabelle-surzur-a8a83182
A relancer?: No
Niveau hiérarchique: COMEX
Rôle dans la décision: Influenceur
Related Décideurs / Clients: Alexis CESBRON (Alexis%20CESBRON%202ffd19e8243380d0af8fdb255d72ad22.md)
Fonction macro: Ressources humaines
Priorité prospection: 🟠 Moyenne
Localisation: Angers