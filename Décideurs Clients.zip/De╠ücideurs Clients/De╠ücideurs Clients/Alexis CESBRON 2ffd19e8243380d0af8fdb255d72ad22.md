# Alexis CESBRON

Entreprise: Etablissements Sogal (CMAI) (../../Entreprises/Entreprises/Etablissements%20Sogal%20(CMAI)%202ffd19e8243380a68c51cbef157854a8.md)
Fonction: HR Manager
Niveau de relation: Inconnu
Linkedin: linkedin.com/in/alexis-cesbron-17962327
A relancer?: No
Manager direct: Isabelle SURZUR (Isabelle%20SURZUR%202ffd19e8243380a8b6e7e573ec58d955.md)
Niveau hiérarchique: N-1
Rôle dans la décision: Prescripteur
Fonction macro: Ressources humaines
Périmètre: France
Localisation: Angers